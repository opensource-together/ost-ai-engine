-- CreateEnum for Platform
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type t JOIN pg_namespace n ON n.oid = t.typnamespace
                   WHERE t.typname = 'Platform' AND n.nspname = 'public') THEN
        CREATE TYPE "public"."Platform" AS ENUM ('GITHUB', 'GITLAB');
    END IF;
END $$;

-- CreateTable trending_project
CREATE TABLE IF NOT EXISTS "public"."trending_project" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "platform" "public"."Platform" NOT NULL,
    "externalId" TEXT NOT NULL,

    "name" TEXT NOT NULL,
    "fullName" TEXT NOT NULL,
    "description" TEXT,

    "htmlUrl" TEXT NOT NULL,
    "homepage" TEXT,
    "defaultBranch" TEXT,
    "visibility" TEXT,

    "language" TEXT,
    "topics" JSONB,
    "license" TEXT,

    "stars" INTEGER NOT NULL DEFAULT 0,
    "forks" INTEGER NOT NULL DEFAULT 0,
    "openIssues" INTEGER,
    "subscribers" INTEGER,
    "archived" BOOLEAN NOT NULL DEFAULT false,

    "owner" TEXT,
    "namespace" TEXT,

    "createdAtSource" TIMESTAMP(3),
    "updatedAtSource" TIMESTAMP(3),
    "lastActivityAtSource" TIMESTAMP(3),

    "trendRank" INTEGER,
    "trendWindow" TEXT,
    "trendCollectedAt" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "trending_project_pkey" PRIMARY KEY ("id")
);

-- Unique constraint on (platform, externalId)
CREATE UNIQUE INDEX IF NOT EXISTS "trending_project_platform_externalId_key"
ON "public"."trending_project" ("platform", "externalId");


